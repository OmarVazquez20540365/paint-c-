﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace paint
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            MandelbrotSet();
        }

        private void MandelbrotSet()
        {
            int width = ventana.Width;
            int heigh = ventana.Height;
            Bitmap bmp = new Bitmap(width, heigh);


            for (int row = 0; row < heigh; row++)
            {   

                for (int col = 0; col < width; col++)
                {
                    double c_re = (col - width / 2.0) * 4.0 / width;
                    double c_im = (row - Height / 2.0) * 4.0 / heigh;
                    int iteracion = 0;
                    double x = 0, y = 0;

                    //aqui ocurren las operaciones del fractal las veces que hayamos puesto como iteracion desden 0 a 1000
                    while (iteracion < 1000 && ((x * x) + (y * y)) <= 4)
                    {
                        double x_temp = (x * x) - (y * y) + c_re;
                        y = 2 * x * y + c_im;
                        x = x_temp;
                        iteracion++;
                    }

                    //aqui se dibujan los pixeles en el picturebox dependiendo de las iteraciones que marca el programa
                    if (iteracion < 1000)
                        bmp.SetPixel(col, row, Color.FromArgb(iteracion % 128, iteracion % 50 * 5, iteracion % 10));
                    else
                        bmp.SetPixel(col, row, Color.Black);
                }
            }

            ventana.Image = bmp;

        }

        // stos botones sirven para volver a paint o salir del programa

        private void btnf1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
