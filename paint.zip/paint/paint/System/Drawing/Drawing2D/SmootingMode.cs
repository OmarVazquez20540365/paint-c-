﻿namespace System.Drawing.Drawing2D
{
    internal class SmootingMode
    {
        public static SmoothingMode AntiAlias { get; internal set; }
    }
}