﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace paint
{
    public partial class Form1 : Form
    {

        Graphics surface;
        Graphics photo;
        int anchopluma = 3;
        int x, y, cx, cy, sx, sy;
        bool move;
        Pen pen;
        int R = 0;
        int G = 0;
        int B = 0;
        Bitmap bmp;
        int mode = 0;

        public Form1()
        {
            InitializeComponent();
            //ASIGNAMOS NUESTRA PROPIEDAD Graphics A Picturebox
            surface = pictureBox3.CreateGraphics();
            // INICIALIZAR UNA PLUMA 
            pen = new Pen(Color.FromArgb(R, G, B), anchopluma);
            anchopluma = trackBar1.Value;
            //INICIALIZAR EL VALOR DE RGB CON EL VALOR DE TEXBOX
            R = int.Parse(txtr.Text);
            G = int.Parse(txtg.Text);
            B = int.Parse(txtb.Text);
            //esto sirve para hacer que no salga pixelado el dibujo en el papel
            surface.SmoothingMode = System.Drawing.Drawing2D.SmootingMode.AntiAlias;
            //INICIALIZAR UN BITMAP QUE SIRVE PARA GUARDAR EL TRABAJO
            bmp = new Bitmap(pictureBox3.Width, pictureBox3.Height);
            //photo sirve para que guarde lo que se genera en el bitmap
            photo = Graphics.FromImage(bmp);
            photo.Clear(Color.White);
            photo.SmoothingMode = System.Drawing.Drawing2D.SmootingMode.AntiAlias;
            pictureBox3.BackgroundImage = bmp;
            pictureBox3.BackgroundImageLayout = ImageLayout.None;




        }

        //EVENTO QUE SE DISPARA AL HACER CLICK Y SOSTENERLO EN EL PICURE BOX
        private void pictureBox3_MouseDown(object sender, MouseEventArgs e)
        {

            move = true;
            cx = e.X;
            cy = e.Y;

            //CAMBIAR EL CURSOR CON UNA CRUZ
            pictureBox1.Cursor = Cursors.Cross;
        }

        //PINTAR
        private void pictureBox3_MouseMove(object sender, MouseEventArgs e)
        {

            if (move)
            {
                if (mode == 0)
                {
                    //LAMAR LA FUNCION PARA CAMBIAR LOS VALORES DEL PINCEL
                    cambiarvaorespluma(int.Parse(txtr.Text), int.Parse(txtg.Text), int.Parse(txtb.Text));
                    //DIBUJAR LINEAS DE LA POSICION ACTUAL DEL CURZOR A LA POSICION DESEADA
                    surface.DrawLine(pen, new Point(x, y), e.Location);
                    photo.DrawLine(pen, new Point(x, y), e.Location);
                }


                if (mode == 4)

                {
                    //cambiar color de la pluma a blanco parra borrar
                    cambiarvaorespluma(255, 255, 255);
                    surface.DrawLine(pen, new Point(x, y), e.Location);
                    photo.DrawLine(pen, new Point(x, y), e.Location);
                }
            }

            pictureBox3.Refresh(); // obliga a que se vuelva a dibujar el control 
            x = e.X;
            y = e.Y;
            sx = e.X - cx;
            sy = e.Y - cy;
        }

        // DEJA DE PINTAR AL SOLTAR EL CLICK DEL PICTURE BOX
        private void pictureBox3_MouseUp(object sender, MouseEventArgs e)
        {
            move = false;
            sx = x - cx;
            sy = y - cy;

            // si modo es 3 al soltar el click se dibuja la ellipse
            if (mode == 3)
            {
                cambiarvaorespluma(int.Parse(txtr.Text), int.Parse(txtg.Text), int.Parse(txtb.Text));
                surface.DrawEllipse(pen, cx, cy, sx, sy);
                photo.DrawEllipse(pen, cx, cy, sx, sy);
            }

            // si modo es 1 al soltar el click se dibuja la Línea
            if (mode == 1)
            {
                cambiarvaorespluma(int.Parse(txtr.Text), int.Parse(txtg.Text), int.Parse(txtb.Text));
                surface.DrawLine(pen, cx, cy, x, y);
                photo.DrawLine(pen, cx, cy, x, y);
            }

            // si modo es 2 al soltar el click se dibuja el Cuadro
            if (mode == 2)
            {
                cambiarvaorespluma(int.Parse(txtr.Text), int.Parse(txtg.Text), int.Parse(txtb.Text));
                surface.DrawRectangle(pen, cx, cy, sx, sy);
                photo.DrawRectangle(pen, cx, cy, sx, sy);
            }

        }

        // EVENTO QUEOCURRE AL ARRASTRAR EL TRACKBAR
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            //AJUSTAR EL ANCHO CON EL VALOR DE TRACKBAR
            anchopluma = trackBar1.Value;
        }

        //botón que sirve para salir del programa
        private void button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        //EVENTO QUE SE DISPARA CUANDO DAMOS CLICK AL BOTÓN GUARDAR
        private void button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();

            //filtro de imagenes en png
            sfd.Filter = "Png Files (*.Png) | *.Png";
            //poner por default el formato png
            sfd.DefaultExt = "png";
            //aplicar las extensiones
            sfd.AddExtension = true;

            //mostrar una ventana de guardado
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                bmp.Save(sfd.FileName, System.Drawing.Imaging.ImageFormat.Png);
            }
        }

        // se utiliza para borrar toda la hoja
        private void button3_Click(object sender, EventArgs e)
        {
            surface.Clear(Color.White);
            photo.Clear(Color.White);
        }

        // cambia a modo 0 = pintar
        private void btnpintar_Click(object sender, EventArgs e)
        {
            mode = 0;
        }

        // cambia a modo 1 = dibujar una linea 
        private void BTNLINEA_Click(object sender, EventArgs e)
        {
            mode = 1;

        }

        // cambia a modo 2 = dibujar un cuadrado o un rectangulo 
        private void BTNCUADRO_Click(object sender, EventArgs e)
        {
            mode = 2;
        }

        // cambia a modo 3 = dibujar una ellipse
        private void button4_Click(object sender, EventArgs e)
        {
            mode = 3;
        }

        private void fractal_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form2 f = new Form2();
            f.Show();

            

        }
        

        // EVENTO QUEOCURRE AL HACER CLIK AL BOTÓN BORRAR
        private void btnborrador_Click(object sender, EventArgs e)
        {
            mode = 4;
        }

        // tiene lugar porque hace falta volver a dibujar la elipse , el cuadrado y la linea para poder visualisarlos
        private void pictureBox3_Paint(object sender, PaintEventArgs e)
        {
            //con esto visualizaremos la linea
            Graphics surface = e.Graphics;
           
            //si mueves el cursor se dibuja la previsualización antes de que lo sueltes
            if (move)
            {
                //previsualiza la ellipse
                if (mode == 3)
                {
                    cambiarvaorespluma(int.Parse(txtr.Text), int.Parse(txtg.Text), int.Parse(txtb.Text));
                    surface.DrawEllipse(pen, cx, cy, sx, sy);
                }

                //previsualiza la linea
                if (mode == 1)
                {
                    cambiarvaorespluma(int.Parse(txtr.Text), int.Parse(txtg.Text), int.Parse(txtb.Text));
                    surface.DrawLine(pen, cx, cy, x, y);
                }

                //previsualiza el cuadrado o el rectangulo
                if (mode == 2)
                {
                    cambiarvaorespluma(int.Parse(txtr.Text), int.Parse(txtg.Text), int.Parse(txtb.Text));
                    surface.DrawRectangle(pen, cx, cy, sx, sy);
                }
            }
        }


       

        // PICTUREBOX QUE MUESTRA EL COLOR DIALOG
        private void pictureBox1_Click(object sender, EventArgs e)
        {

            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                //ASIGNAR AL TEXTBOX EL VALOR DEL COLOR SELECCIONADO
                txtr.Text = colorDialog.Color.R.ToString();
                txtg.Text = colorDialog.Color.G.ToString();
                txtb.Text = colorDialog.Color.B.ToString();
            }
        }

        //PASAR A COLOR NEGRO LA BROCHA
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            txtr.Text = txtg.Text = txtb.Text = 0.ToString();
        }

        //cambiar el valor de la pluma 
        private void cambiarvaorespluma(int R, int G , int B)
        {
            pen = new Pen(Color.FromArgb(R,G,B), trackBar1.Value);

            //LOS TRAZOS INICIAN Y TERMINAN DE MANERA OVALADA 
            pen.StartCap = pen.EndCap = System.Drawing.Drawing2D.LineCap.Round;
        }

    }

}