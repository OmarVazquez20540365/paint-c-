﻿
namespace paint
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnf1 = new System.Windows.Forms.Button();
            this.ventana = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ventana)).BeginInit();
            this.SuspendLayout();
            // 
            // btnf1
            // 
            this.btnf1.BackColor = System.Drawing.Color.Silver;
            this.btnf1.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnf1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnf1.Image = global::paint.Properties.Resources.pincel;
            this.btnf1.Location = new System.Drawing.Point(12, 413);
            this.btnf1.Name = "btnf1";
            this.btnf1.Size = new System.Drawing.Size(35, 33);
            this.btnf1.TabIndex = 3;
            this.btnf1.UseVisualStyleBackColor = false;
            this.btnf1.Click += new System.EventHandler(this.btnf1_Click);
            // 
            // ventana
            // 
            this.ventana.BackColor = System.Drawing.Color.Black;
            this.ventana.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ventana.Location = new System.Drawing.Point(12, 12);
            this.ventana.Name = "ventana";
            this.ventana.Size = new System.Drawing.Size(476, 395);
            this.ventana.TabIndex = 4;
            this.ventana.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = global::paint.Properties.Resources.exit;
            this.button1.Location = new System.Drawing.Point(63, 413);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 33);
            this.button1.TabIndex = 5;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(500, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnf1);
            this.Controls.Add(this.ventana);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.ventana)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnf1;
        private System.Windows.Forms.PictureBox ventana;
        private System.Windows.Forms.Button button1;
    }
}