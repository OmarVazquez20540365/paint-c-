﻿
namespace paint
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.txtb = new System.Windows.Forms.TextBox();
            this.txtg = new System.Windows.Forms.TextBox();
            this.txtr = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnpintar = new System.Windows.Forms.Button();
            this.btnborrador = new System.Windows.Forms.Button();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.BTNLINEA = new System.Windows.Forms.Button();
            this.BTNCUADRO = new System.Windows.Forms.Button();
            this.BTNELLIPSE = new System.Windows.Forms.Button();
            this.fractal = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(91, 446);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(31, 32);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Black;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Location = new System.Drawing.Point(128, 446);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(31, 32);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // trackBar1
            // 
            this.trackBar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(146)))), ((int)(((byte)(190)))));
            this.trackBar1.Location = new System.Drawing.Point(397, 10);
            this.trackBar1.Maximum = 20;
            this.trackBar1.Minimum = 1;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(225, 45);
            this.trackBar1.TabIndex = 2;
            this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trackBar1.Value = 5;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(104, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "R";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(202, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "G";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(300, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "B";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(146)))), ((int)(((byte)(190)))));
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.txtb);
            this.panel1.Controls.Add(this.txtg);
            this.panel1.Controls.Add(this.trackBar1);
            this.panel1.Controls.Add(this.txtr);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(821, 58);
            this.panel1.TabIndex = 6;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(0, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(85, 57);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox4.TabIndex = 12;
            this.pictureBox4.TabStop = false;
            // 
            // txtb
            // 
            this.txtb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtb.Location = new System.Drawing.Point(320, 21);
            this.txtb.Name = "txtb";
            this.txtb.Size = new System.Drawing.Size(71, 20);
            this.txtb.TabIndex = 11;
            this.txtb.Text = "0";
            // 
            // txtg
            // 
            this.txtg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtg.Location = new System.Drawing.Point(223, 21);
            this.txtg.Name = "txtg";
            this.txtg.Size = new System.Drawing.Size(71, 20);
            this.txtg.TabIndex = 10;
            this.txtg.Text = "0";
            // 
            // txtr
            // 
            this.txtr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtr.Location = new System.Drawing.Point(125, 21);
            this.txtr.Name = "txtr";
            this.txtr.Size = new System.Drawing.Size(71, 20);
            this.txtr.TabIndex = 9;
            this.txtr.Text = "0";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(517, 446);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(31, 32);
            this.button3.TabIndex = 8;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(554, 446);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(31, 32);
            this.button2.TabIndex = 7;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(591, 446);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(31, 32);
            this.button1.TabIndex = 6;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox3.Location = new System.Drawing.Point(12, 70);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(610, 368);
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox3_Paint);
            this.pictureBox3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox3_MouseDown);
            this.pictureBox3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox3_MouseMove);
            this.pictureBox3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox3_MouseUp);
            // 
            // btnpintar
            // 
            this.btnpintar.BackColor = System.Drawing.Color.Transparent;
            this.btnpintar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnpintar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnpintar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpintar.Image = ((System.Drawing.Image)(resources.GetObject("btnpintar.Image")));
            this.btnpintar.Location = new System.Drawing.Point(12, 446);
            this.btnpintar.Name = "btnpintar";
            this.btnpintar.Size = new System.Drawing.Size(31, 32);
            this.btnpintar.TabIndex = 8;
            this.btnpintar.UseVisualStyleBackColor = false;
            this.btnpintar.Click += new System.EventHandler(this.btnpintar_Click);
            // 
            // btnborrador
            // 
            this.btnborrador.BackColor = System.Drawing.Color.Transparent;
            this.btnborrador.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnborrador.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnborrador.Image = ((System.Drawing.Image)(resources.GetObject("btnborrador.Image")));
            this.btnborrador.Location = new System.Drawing.Point(54, 446);
            this.btnborrador.Name = "btnborrador";
            this.btnborrador.Size = new System.Drawing.Size(31, 32);
            this.btnborrador.TabIndex = 9;
            this.btnborrador.UseVisualStyleBackColor = false;
            this.btnborrador.Click += new System.EventHandler(this.btnborrador_Click);
            // 
            // BTNLINEA
            // 
            this.BTNLINEA.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BTNLINEA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNLINEA.Image = ((System.Drawing.Image)(resources.GetObject("BTNLINEA.Image")));
            this.BTNLINEA.Location = new System.Drawing.Point(242, 446);
            this.BTNLINEA.Name = "BTNLINEA";
            this.BTNLINEA.Size = new System.Drawing.Size(31, 32);
            this.BTNLINEA.TabIndex = 10;
            this.BTNLINEA.UseVisualStyleBackColor = true;
            this.BTNLINEA.Click += new System.EventHandler(this.BTNLINEA_Click);
            // 
            // BTNCUADRO
            // 
            this.BTNCUADRO.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BTNCUADRO.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNCUADRO.Image = ((System.Drawing.Image)(resources.GetObject("BTNCUADRO.Image")));
            this.BTNCUADRO.Location = new System.Drawing.Point(205, 446);
            this.BTNCUADRO.Name = "BTNCUADRO";
            this.BTNCUADRO.Size = new System.Drawing.Size(31, 32);
            this.BTNCUADRO.TabIndex = 11;
            this.BTNCUADRO.UseVisualStyleBackColor = true;
            this.BTNCUADRO.Click += new System.EventHandler(this.BTNCUADRO_Click);
            // 
            // BTNELLIPSE
            // 
            this.BTNELLIPSE.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BTNELLIPSE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNELLIPSE.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNELLIPSE.Image = ((System.Drawing.Image)(resources.GetObject("BTNELLIPSE.Image")));
            this.BTNELLIPSE.Location = new System.Drawing.Point(168, 446);
            this.BTNELLIPSE.Name = "BTNELLIPSE";
            this.BTNELLIPSE.Size = new System.Drawing.Size(31, 32);
            this.BTNELLIPSE.TabIndex = 13;
            this.BTNELLIPSE.UseVisualStyleBackColor = true;
            this.BTNELLIPSE.Click += new System.EventHandler(this.button4_Click);
            // 
            // fractal
            // 
            this.fractal.BackColor = System.Drawing.Color.Transparent;
            this.fractal.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.fractal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fractal.Image = global::paint.Properties.Resources.fractal;
            this.fractal.Location = new System.Drawing.Point(280, 446);
            this.fractal.Name = "fractal";
            this.fractal.Size = new System.Drawing.Size(34, 32);
            this.fractal.TabIndex = 14;
            this.fractal.UseVisualStyleBackColor = false;
            this.fractal.Click += new System.EventHandler(this.fractal_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(636, 507);
            this.Controls.Add(this.fractal);
            this.Controls.Add(this.BTNELLIPSE);
            this.Controls.Add(this.BTNCUADRO);
            this.Controls.Add(this.BTNLINEA);
            this.Controls.Add(this.btnborrador);
            this.Controls.Add(this.btnpintar);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TextBox txtb;
        private System.Windows.Forms.TextBox txtg;
        private System.Windows.Forms.TextBox txtr;
        private System.Windows.Forms.Button btnpintar;
        private System.Windows.Forms.Button btnborrador;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button BTNLINEA;
        private System.Windows.Forms.Button BTNCUADRO;
        private System.Windows.Forms.Button BTNELLIPSE;
        private System.Windows.Forms.Button fractal;
    }
}

